/**
 * Created by parin on 4 jun 2017.
 */

'use strict';
var restaurant = angular.module('restaurant', []);
modules.push('restaurant');

restaurant.config(function ($stateProvider) {
    $stateProvider
            .state('app.restaurant', {
                url: '/restaurant',
                templateUrl: 'partials/restaurant/restaurant.html',
                controller: 'restaurantCtrl'
            })
            .state('app.restaurant.add', {
                url: '/add',
                templateUrl: 'partials/restaurant/add.html ',
                controller: 'addRestaurantCtrl'
            })
            .state('app.restaurant.edit', {
                url: '/edit/:id',
                templateUrl: 'partials/restaurant/edit.html ',
                controller: 'editRestaurantCtrl',
            })
});

restaurant.controller('restaurantCtrl', function ($scope, Restaurant) {

    $scope.restaurants = [];

    Restaurant.$loaded().then(function (x) {
        $scope.restaurants = x;
    })

    $scope.deleteFn = function (restaurant, index) {
        Restaurant.$remove(restaurant).then(function (res) {
            $scope.setFlash('s', 'Deleted Successfull');
        }).catch(function (error) {
            $scope.setFlash('e', error);
        });
    }
});

restaurant.controller('addRestaurantCtrl', function ($scope, $timeout, Restaurant) {

    var ImageStorage = storage.ref();

    $timeout(function () {
        $('.addModal').modal('show');
        $('.addModal').on('hidden.bs.modal', function () {
            $scope.goTo('app.restaurant');
        })
    }, true);

    $scope.add = {};
    $scope.hours = {
        days1: 'Mon,Tue,Wed,Thur',
        starttime1: moment().hour(6).minute(30).toDate(),
        endtime1: moment().hour(22).minute(0).toDate(),
        days2: 'Fri',
        starttime2: moment().hour(6).minute(30).toDate(),
        endtime2: moment().hour(23).minute(0).toDate(),
        days3: 'Sat',
        starttime3: moment().hour(7).minute(0).toDate(),
        endtime3: moment().hour(23).minute(0).toDate(),
        days4: 'Sun',
        starttime4: moment().hour(7).minute(0).toDate(),
        endtime4: moment().hour(22).minute(0).toDate(),
    };

    $scope.addFn = function () {

        if ($scope.add.logo) {
            var imagesRef = ImageStorage.child($scope.add.logo.file.name);

            imagesRef.put($scope.add.logo.file).then(function () {
                console.log('Uploaded a blob or file!');
            });

            $scope.add.logo = $scope.add.logo.file.name;

        }

        if ($scope.add.pictures) {

            var pictures = [];

            _.each($scope.add.pictures, function (nw) {
                var imagesRef = ImageStorage.child(nw.file.name);
                pictures.push(nw.file.name);

                imagesRef.put(nw.file).then(function () {
                    console.log('Uploaded a blob or file!');
                });
            })
            $scope.add.pictures = pictures;
        }

        if ($scope.add.menu_image) {
            var imagesRef = ImageStorage.child($scope.add.menu_image.file.name);

            imagesRef.put($scope.add.menu_image.file).then(function () {
                console.log('Uploaded a blob or file!');
            });
            $scope.add.menu_image = $scope.add.menu_image.file.name;
        }

        $scope.add.hours = 'Mon\t' + moment($scope.hours.starttime1).format('LT') + ' - ' + moment($scope.hours.endtime1).format('LT') + '\n'
                + 'Tue\t' + moment($scope.hours.starttime1).format('LT') + ' - ' + moment($scope.hours.endtime1).format('LT') + '\n'
                + 'Wed\t' + moment($scope.hours.starttime1).format('LT') + ' - ' + moment($scope.hours.endtime1).format('LT') + '\n'
                + 'Thur\t' + moment($scope.hours.starttime1).format('LT') + ' - ' + moment($scope.hours.endtime1).format('LT') + '\n'
                + 'Fri\t' + moment($scope.hours.starttime2).format('LT') + ' - ' + moment($scope.hours.endtime2).format('LT') + '\n'
                + 'Sat\t' + moment($scope.hours.starttime3).format('LT') + ' - ' + moment($scope.hours.endtime3).format('LT') + '\n'
                + 'Sun\t' + moment($scope.hours.starttime4).format('LT') + ' - ' + moment($scope.hours.endtime4).format('LT') + '\n';

        Restaurant.$add($scope.add).then(function (res) {

            $scope.setFlash('s', 'Success');
            $('.addModal').modal('hide');
        }).catch(function (error) {
            $scope.setFlash('e', 'Error!' + error);
            $('.addModal').modal('hide');
        });
    }
});

restaurant.controller('editRestaurantCtrl', function ($scope, $timeout, $stateParams, Restaurant) {
    var ImageStorage = storage.ref();
    $timeout(function () {
        $('.editModal').modal('show');
        $('.editModal').on('hidden.bs.modal', function () {
            $scope.goTo('app.restaurant');
        })
    }, true);

    $scope.edit = _.findWhere($scope.restaurants, {$id: $stateParams.id});
    console.log($scope.edit);
    $scope.upload = {};
//    console.log($scope.edit);
//    if ($scope.edit.logo) {
//        var pathReference = storage.ref($scope.edit.logo);
//        pathReference.getDownloadURL().then(function (url) {
//            $scope.upload.logo = url;
//            $("#logo").src = url;
//            console.log(url);
//        }).catch(function (error) {
//            $scope.setFlash('e', 'Error!' + error);
//        });
//    }

    $scope.getImageUrl = function (image) {
        var pathReference = storage.ref(image);
        pathReference.getDownloadURL().then(function (url) {
            console.log(url)
//            document.querySelector('img').src = url;
            var img = document.getElementById('logo');
            img.src = url;
//            return url;
        }).catch(function (error) {
            $scope.setFlash('e', 'Error!' + error);
        });
    }
    if ($scope.edit.logo) {
        $scope.getImageUrl($scope.edit.logo);
    }
//    console.log($scope.getImageUrl($scope.edit.logo));
    if ($scope.edit.menu_image) {
        var pathReference = storage.ref($scope.edit.menu_image);
        pathReference.getDownloadURL().then(function (url) {
            var img = document.getElementById('menu_image');
            img.src = url;
        }).catch(function (error) {
            $scope.setFlash('e', 'Error!' + error);
        });
    }

    if ($scope.edit.pictures && $scope.edit.pictures.length) {
        _.each($scope.edit.pictures, function (pic, index) {
            var pathReference = storage.ref(pic);
            pathReference.getDownloadURL().then(function (url) {
                var img = document.getElementById('pic' + index);
                img.src = url;
            }).catch(function (error) {
                $scope.setFlash('e', 'Error!' + error);
            });
        })
    }


    var hour = $scope.edit.hours
            .replace('Mon', '').replace('Tue', '').replace('Wed', '')
            .replace('Thur', '').replace('Fri', '').replace('Sat', '').replace('Sun', '')
            .replace(/\t/g, "")
            .replace(/\n/g, ',')
            .split(",");

    function get_date(time) {
        var d = new Date(),
                parts = time.match(/(\d+)\:(\d+) (\w+)/),
                hours = /am/i.test(parts[3]) ? parseInt(parts[1], 10) : parseInt(parts[1], 10) + 12,
                minutes = parseInt(parts[2], 10);

        d.setHours(hours);
        d.setMinutes(minutes);
        return d;
    }

    var time1 = hour[0].split(" - ");
    var time2 = hour[4].split(" - ");
    var time3 = hour[5].split(" - ");
    var time4 = hour[6].split(" - ");

    $scope.hours = {
        days1: 'Mon,Tue,Wed,Thur',
        starttime1: get_date(time1[0]),
        endtime1: get_date(time1[1]),
        days2: 'Fri',
        starttime2: get_date(time2[0]),
        endtime2: get_date(time2[1]),
        days3: 'Sat',
        starttime3: get_date(time3[0]),
        endtime3: get_date(time3[1]),
        days4: 'Sun',
        starttime4: get_date(time4[0]),
        endtime4: get_date(time4[1]),
    };




    $scope.editFn = function () {

        if ($scope.edit.logo && $scope.edit.logo.file) {
            var imagesRef = ImageStorage.child($scope.edit.logo.file.name);

            imagesRef.put($scope.edit.logo.file).then(function () {
                console.log('Uploaded a blob or file!');
            });

            $scope.edit.logo = $scope.edit.logo.file.name;

        }

        if ($scope.edit.pictures) {

            var pictures = [];
            var flag = false;
            _.each($scope.edit.pictures, function (nw) {
                if (nw.file) {
                    var imagesRef = ImageStorage.child(nw.file.name);
                    pictures.push(nw.file.name);
                    flag = true;
                    imagesRef.put(nw.file).then(function () {
                        console.log('Uploaded a blob or file!');
                    });
                }
            })
            if (flag) {
                $scope.edit.pictures = pictures;
            }
        }

        if ($scope.edit.menu_image && $scope.edit.menu_image.file) {
            var imagesRef = ImageStorage.child($scope.edit.menu_image.file.name);

            imagesRef.put($scope.edit.menu_image.file).then(function () {
                console.log('Uploaded a blob or file!');
            });
            $scope.edit.menu_image = $scope.edit.menu_image.file.name;
        }

        $scope.edit.hours = 'Mon\t' + moment($scope.hours.starttime1).format('LT') + ' - ' + moment($scope.hours.endtime1).format('LT') + '\n'
                + 'Tue\t' + moment($scope.hours.starttime1).format('LT') + ' - ' + moment($scope.hours.endtime1).format('LT') + '\n'
                + 'Wed\t' + moment($scope.hours.starttime1).format('LT') + ' - ' + moment($scope.hours.endtime1).format('LT') + '\n'
                + 'Thur\t' + moment($scope.hours.starttime1).format('LT') + ' - ' + moment($scope.hours.endtime1).format('LT') + '\n'
                + 'Fri\t' + moment($scope.hours.starttime2).format('LT') + ' - ' + moment($scope.hours.endtime2).format('LT') + '\n'
                + 'Sat\t' + moment($scope.hours.starttime3).format('LT') + ' - ' + moment($scope.hours.endtime3).format('LT') + '\n'
                + 'Sun\t' + moment($scope.hours.starttime4).format('LT') + ' - ' + moment($scope.hours.endtime4).format('LT') + '\n';

        Restaurant.$save($scope.edit).then(function () {
            $scope.setFlash('s', 'Success');
            $('.editModal').modal('hide');
        }).catch(function (error) {
            $scope.setFlash('e', 'Error!' + error);
            $('.editModal').modal('hide');
        });
    }

});